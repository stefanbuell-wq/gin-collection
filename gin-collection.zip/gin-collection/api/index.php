<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once 'Database.php';

class GinAPI {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    public function handleRequest() {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = isset($_GET['action']) ? $_GET['action'] : '';

        try {
            switch ($path) {
                case 'list':
                    if ($method === 'GET') {
                        $this->listGins();
                    }
                    break;

                case 'get':
                    if ($method === 'GET' && isset($_GET['id'])) {
                        $this->getGin($_GET['id']);
                    }
                    break;

                case 'add':
                    if ($method === 'POST') {
                        $this->addGin();
                    }
                    break;

                case 'update':
                    if ($method === 'PUT' || $method === 'POST') {
                        $this->updateGin();
                    }
                    break;

                case 'delete':
                    if ($method === 'DELETE' || $method === 'POST') {
                        $this->deleteGin();
                    }
                    break;

                case 'stats':
                    if ($method === 'GET') {
                        $this->getStats();
                    }
                    break;

                case 'search':
                    if ($method === 'GET') {
                        $this->searchGins();
                    }
                    break;

                case 'barcode':
                    if ($method === 'GET' && isset($_GET['code'])) {
                        $this->lookupBarcode($_GET['code']);
                    }
                    break;

                case 'upload':
                    if ($method === 'POST') {
                        $this->uploadPhoto();
                    }
                    break;

                default:
                    $this->sendResponse(['error' => 'Invalid endpoint'], 404);
            }
        } catch (Exception $e) {
            $this->sendResponse(['error' => $e->getMessage()], 500);
        }
    }

    private function listGins() {
        $filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
        $sort = isset($_GET['sort']) ? $_GET['sort'] : 'name';
        
        $where = $filter === 'available' ? 'WHERE is_finished = 0' : 
                ($filter === 'finished' ? 'WHERE is_finished = 1' : '');
        
        $orderBy = match($sort) {
            'rating' => 'rating DESC, name',
            'price' => 'price DESC',
            'date' => 'purchase_date DESC',
            'country' => 'country, name',
            default => 'name'
        };

        $stmt = $this->db->query("
            SELECT id, name, brand, country, abv, price, rating, photo_url, is_finished, barcode
            FROM gins 
            $where
            ORDER BY $orderBy
        ");

        $gins = $stmt->fetchAll();
        $this->sendResponse(['gins' => $gins]);
    }

    private function getGin($id) {
        $stmt = $this->db->prepare("SELECT * FROM gins WHERE id = ?");
        $stmt->execute([$id]);
        $gin = $stmt->fetch();

        if ($gin) {
            // Get botanicals if any
            $stmt = $this->db->prepare("
                SELECT b.name 
                FROM botanicals b
                JOIN gin_botanicals gb ON b.id = gb.botanical_id
                WHERE gb.gin_id = ?
            ");
            $stmt->execute([$id]);
            $gin['botanicals'] = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $this->sendResponse(['gin' => $gin]);
        } else {
            $this->sendResponse(['error' => 'Gin not found'], 404);
        }
    }

    private function addGin() {
        $data = json_decode(file_get_contents('php://input'), true);

        $stmt = $this->db->prepare("
            INSERT INTO gins (name, brand, country, region, abv, bottle_size, price, 
                            purchase_date, barcode, rating, tasting_notes, description, photo_url)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $data['name'] ?? null,
            $data['brand'] ?? null,
            $data['country'] ?? null,
            $data['region'] ?? null,
            $data['abv'] ?? null,
            $data['bottle_size'] ?? 700,
            $data['price'] ?? null,
            $data['purchase_date'] ?? date('Y-m-d'),
            $data['barcode'] ?? null,
            $data['rating'] ?? null,
            $data['tasting_notes'] ?? null,
            $data['description'] ?? null,
            $data['photo_url'] ?? null
        ]);

        $id = $this->db->lastInsertId();
        $this->sendResponse(['success' => true, 'id' => $id]);
    }

    private function updateGin() {
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['id'] ?? null;

        if (!$id) {
            $this->sendResponse(['error' => 'ID required'], 400);
            return;
        }

        $stmt = $this->db->prepare("
            UPDATE gins SET 
                name = ?, brand = ?, country = ?, region = ?, abv = ?, 
                bottle_size = ?, price = ?, purchase_date = ?, barcode = ?,
                rating = ?, tasting_notes = ?, description = ?, photo_url = ?, is_finished = ?
            WHERE id = ?
        ");

        $stmt->execute([
            $data['name'] ?? null,
            $data['brand'] ?? null,
            $data['country'] ?? null,
            $data['region'] ?? null,
            $data['abv'] ?? null,
            $data['bottle_size'] ?? 700,
            $data['price'] ?? null,
            $data['purchase_date'] ?? null,
            $data['barcode'] ?? null,
            $data['rating'] ?? null,
            $data['tasting_notes'] ?? null,
            $data['description'] ?? null,
            $data['photo_url'] ?? null,
            $data['is_finished'] ?? 0,
            $id
        ]);

        $this->sendResponse(['success' => true]);
    }

    private function deleteGin() {
        $data = json_decode(file_get_contents('php://input'), true);
        $id = $data['id'] ?? $_GET['id'] ?? null;

        if (!$id) {
            $this->sendResponse(['error' => 'ID required'], 400);
            return;
        }

        $stmt = $this->db->prepare("DELETE FROM gins WHERE id = ?");
        $stmt->execute([$id]);

        $this->sendResponse(['success' => true]);
    }

    private function getStats() {
        $stats = [];

        // Total count
        $stmt = $this->db->query("SELECT COUNT(*) as total FROM gins");
        $stats['total'] = $stmt->fetch()['total'];

        // Available vs finished
        $stmt = $this->db->query("SELECT COUNT(*) as available FROM gins WHERE is_finished = 0");
        $stats['available'] = $stmt->fetch()['available'];
        $stats['finished'] = $stats['total'] - $stats['available'];

        // Average rating
        $stmt = $this->db->query("SELECT AVG(rating) as avg_rating FROM gins WHERE rating IS NOT NULL");
        $stats['avg_rating'] = round($stmt->fetch()['avg_rating'], 1);

        // Total value
        $stmt = $this->db->query("SELECT SUM(price) as total_value FROM gins WHERE price IS NOT NULL");
        $stats['total_value'] = round($stmt->fetch()['total_value'], 2);

        // Countries
        $stmt = $this->db->query("
            SELECT country, COUNT(*) as count 
            FROM gins 
            WHERE country IS NOT NULL 
            GROUP BY country 
            ORDER BY count DESC
        ");
        $stats['countries'] = $stmt->fetchAll();

        // Top rated
        $stmt = $this->db->query("
            SELECT name, brand, rating, photo_url
            FROM gins 
            WHERE rating IS NOT NULL 
            ORDER BY rating DESC, name
            LIMIT 5
        ");
        $stats['top_rated'] = $stmt->fetchAll();

        $this->sendResponse(['stats' => $stats]);
    }

    private function searchGins() {
        $query = $_GET['q'] ?? '';
        
        if (empty($query)) {
            $this->listGins();
            return;
        }

        $stmt = $this->db->prepare("
            SELECT id, name, brand, country, abv, price, rating, photo_url, is_finished
            FROM gins 
            WHERE name LIKE ? OR brand LIKE ? OR country LIKE ? OR tasting_notes LIKE ?
            ORDER BY name
        ");

        $searchTerm = "%$query%";
        $stmt->execute([$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
        $gins = $stmt->fetchAll();

        $this->sendResponse(['gins' => $gins]);
    }

    private function lookupBarcode($barcode) {
        // First check if we already have this gin
        $stmt = $this->db->prepare("SELECT * FROM gins WHERE barcode = ?");
        $stmt->execute([$barcode]);
        $existing = $stmt->fetch();

        if ($existing) {
            $this->sendResponse(['exists' => true, 'gin' => $existing]);
            return;
        }

        // Try to lookup via Open Food Facts API
        $url = "https://world.openfoodfacts.org/api/v0/product/{$barcode}.json";
        $response = @file_get_contents($url);

        if ($response) {
            $data = json_decode($response, true);
            
            if ($data['status'] === 1) {
                $product = $data['product'];
                $ginData = [
                    'exists' => false,
                    'name' => $product['product_name'] ?? '',
                    'brand' => $product['brands'] ?? '',
                    'country' => $product['countries'] ?? '',
                    'abv' => $product['alcohol_volume'] ?? null,
                    'photo_url' => $product['image_url'] ?? null,
                    'barcode' => $barcode
                ];
                $this->sendResponse($ginData);
                return;
            }
        }

        $this->sendResponse(['exists' => false, 'found' => false, 'barcode' => $barcode]);
    }

    private function uploadPhoto() {
        if (!isset($_FILES['photo'])) {
            $this->sendResponse(['error' => 'No photo uploaded'], 400);
            return;
        }

        $file = $_FILES['photo'];
        $uploadDir = __DIR__ . '/../uploads/';
        
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        // Generate unique filename
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = uniqid('gin_') . '.' . $extension;
        $filepath = $uploadDir . $filename;

        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            $url = '/uploads/' . $filename;
            $this->sendResponse(['success' => true, 'url' => $url]);
        } else {
            $this->sendResponse(['error' => 'Upload failed'], 500);
        }
    }

    private function sendResponse($data, $status = 200) {
        http_response_code($status);
        echo json_encode($data);
        exit;
    }
}

// Initialize and handle request
$api = new GinAPI();
$api->handleRequest();
